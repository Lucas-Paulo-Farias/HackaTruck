//
//  MenuMotoristaView.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 15/05/25.
//

import SwiftUI

struct MenuMotoristaView: View {
    var body: some View {
        TabView {
            MotoristaView()
                .tabItem {
                    Label("PERFIL", systemImage: "person.circle.fill")
                }
            MapaMotoraView()
                .tabItem {
                    Label("MAPA", systemImage: "map.fill")
                }
            NotfMotoraView()
                .tabItem {
                    Label("NOTIFICAÇÕES", systemImage: "bell.badge.fill")
                }
            
            ConfigMotoraView()
                .tabItem {
                    Label("CONFIGURAÇÕES", systemImage: "gearshape.2.fill")
                }
        }
    }
}

#Preview {
    MenuMotoristaView()
}
