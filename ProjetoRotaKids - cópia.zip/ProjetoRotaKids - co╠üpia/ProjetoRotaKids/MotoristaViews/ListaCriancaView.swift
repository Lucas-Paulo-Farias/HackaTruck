//
//  ListaCriancaView.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 16/05/25.
//

import SwiftUI

struct ListaCriancasView: View {
    @StateObject var vm = ViewModelMotorista()
    
    var body: some View {
        NavigationStack{
            ZStack{
                Color.azulclaro
                    .ignoresSafeArea(.all)
                VStack {
                    Image(.rotakidspng)
                        .resizable()
                        .frame(width: 180, height: 180)
                    ScrollView(.vertical){
                        ForEach(vm.motora, id: \.self){index in
                            
                            ForEach(index.veiculos.criancas, id: \.self){
                                kid in
                                
                                HStack {
                                    NavigationLink(destination: CriancaView()){
                                        AsyncImage(url: URL(string: kid.foto)){ image in
                                            image
                                                .image?.resizable()
                                        }
                                        .frame(width: 80, height: 80)
                                        .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/, style: /*@START_MENU_TOKEN@*/FillStyle()/*@END_MENU_TOKEN@*/)
                                        VStack(alignment: .leading){
                                            Text(kid.apelido)
                                                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                                                .foregroundStyle(.black)
                                            Text(index.veiculos.modelo)
                                                .font(.subheadline)
                                                .foregroundStyle(.black)
                                        }
                                        Spacer()
        
                                        HStack{
                                            Button(action: {} , label: {
                                                Circle()
                                                    .fill(.green)
                                                    .frame(width: 30, height: 30)
                                            })
                                            .padding(8.0)
                                            Button(action: {} , label: {
                                                Circle()
                                                    .fill(.red)
                                                    .frame(width: 30, height: 30)
                                            })
                                        }
                                        .padding()
                                    }
                                }
                            }
                        }
                        
                    }
                }
            }
        }
        .onAppear(){
            vm.fetch()
        }
    }
}

#Preview {
    ListaCriancasView()
}

