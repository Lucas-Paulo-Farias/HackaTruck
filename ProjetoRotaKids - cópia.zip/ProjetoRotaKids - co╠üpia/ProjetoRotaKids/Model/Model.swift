//
//  Model.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 13/05/25.
//

import Foundation

struct Motorista: Decodable, Hashable {
    let idMotora: String
    let nome: String
    let cnh: String
    let foto: String
    let telefone: String
    let veiculos: Veiculo
}

struct Veiculo: Decodable, Hashable {
    let placa: String
    let modelo: String
    let foto: String
    let cor: String
    let latitude: Double
    let longitude: Double
    let criancas: [Crianca]
}

struct Pai: Decodable, Hashable {
    let idPai: String
    let nome: String
    let foto: String
    let telefone: String
    let enderecoLat: Double
    let enderecoLong: Double
    let criancas: [Crianca]
}

struct Crianca: Decodable, Hashable {
    let idPai: String
    let apelido: String
    let foto: String
    let colegio: String
    let horario: String
    let colLat: Double
    let colLon: Double
    let observacoes: String
}
struct CadastroPaiFilho: Codable {
    let nomeResponsavel: String
    let telefoneResponsavel: String
    let enderecoResponsavel: String
    let apelidoCrianca: String
    let observacoesCrianca: String?
}

struct Localizacao: Codable, Hashable {
    let latitude: Double
    let longitude: Double
    let timestamp: Date
}

struct AtribuicaoVanCrianca: Codable, Hashable {
    let vanId: Int
    let criancaId: Int
}

struct Message: Encodable {
    let motoId: String
    let paraPai: String
    let status: Bool
}
