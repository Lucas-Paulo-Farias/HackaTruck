//
//  TabView.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 14/05/25.
//

import SwiftUI

struct TabView: View {
    var body: some View {
        TabView {
            PaiView()
                .tabItem {
                    Label("PERFIL", systemImage: "person.circle.fill")
                }
        }
    }
}

#Preview {
    TabView()
}
