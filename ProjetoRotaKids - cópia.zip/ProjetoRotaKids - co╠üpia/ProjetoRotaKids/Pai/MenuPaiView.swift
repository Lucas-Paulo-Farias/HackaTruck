//
//  MenuPaiView.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 14/05/25.
//

import SwiftUI

struct MenuPaiView: View {
    var body: some View {
        TabView {
            PaiView()
                .tabItem {
                    Label("PERFIL", systemImage: "person.circle.fill")
                }
            
            NotfView()
                .tabItem {
                    Label("NOTIFICAÇÕES", systemImage: "bell.badge.fill")
                }
            
            ConfigPaiView()
                .tabItem {
                    Label("CONFIGURAÇÕES", systemImage: "gearshape.2.fill")
                }
        }
    }
}

#Preview {
    MenuPaiView()
}
