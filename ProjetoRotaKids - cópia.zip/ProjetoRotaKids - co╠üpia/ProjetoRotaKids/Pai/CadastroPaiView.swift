//
//  CadastroView.swift
//  testerotakids
//
//  Created by Igor Teles Lima  on 15/05/25.
//

import SwiftUI

struct CadastroPaiView: View {
  @StateObject var viewmodelcadastro = ViewModelCadastro()
    
    var body: some View {
        ZStack {
            Color.azulclaro
                .ignoresSafeArea()
            
            ScrollView {
                VStack(alignment: .leading) {
                    HStack {
                        Image("RotaKids")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80, height: 80)
                        Spacer()
                    }
                    .padding(.horizontal)
                    .background()
                    
                    VStack(alignment: .leading) {
                        Text("Nome do Responsável:")
                            .foregroundColor(.laranja)
                            .bold()
                            .font(.system(size: 22))
                        TextField("  Nome:", text: $viewmodelcadastro.nome)
                            .background(RoundedRectangle(cornerRadius: 50).fill(.white).frame(height: 30))
                        
                        Text("Telefone do Responsável:")
                            .bold()
                            .foregroundColor(.laranja)
                            .font(.system(size: 22))
                        TextField("  Telefone:", text: $viewmodelcadastro.telefone)
                            .background(RoundedRectangle(cornerRadius: 50).fill(.white).frame(height: 30))
                        
                        Text("Endereço:")
                            .bold()
                            .foregroundColor(.laranja)
                            .font(.system(size: 22))
                        TextField("  Endereço:", text: $viewmodelcadastro.endereco)
                            .background(RoundedRectangle(cornerRadius: 50).fill(.white).frame(height: 30))
                        
                        Text("Criança:")
                            .bold()
                            .foregroundColor(.laranja)
                            .font(.system(size: 22))
                        TextField("  Apelido:", text: $viewmodelcadastro.apelido)
                            .background(RoundedRectangle(cornerRadius: 50).fill(.white).frame(height: 30))
                        
                        Text("Observações:")
                            .bold()
                            .foregroundColor(.laranja)
                            .font(.system(size: 22))
                        TextField("  Observações:", text: $viewmodelcadastro.observacoes, axis: .vertical)
                            .textFieldStyle(.roundedBorder)
                        
                        Spacer(minLength: 40)
                    }
                    .padding(.horizontal)
                    
                    HStack {
                        Spacer()
                        Button("Cadastrar") {
                            viewmodelcadastro.enviarDadosCadastro()
                        }
                        .foregroundColor(.white)
                        .bold()
                        .padding(.horizontal, 40)
                        .padding(.vertical, 15)
                        .background(RoundedRectangle(cornerRadius: 50).fill(.azul))
                        .padding(.trailing, 20)
                        .disabled(viewmodelcadastro.isLoading) // Desabilita o botão durante o carregamento
                        
                        if viewmodelcadastro.isLoading {
                            ProgressView()
                        }
                        Spacer()
                    }
                    .padding(.horizontal)
                    
                    Spacer()
                }
            }
        }
        .alert(isPresented: $viewmodelcadastro.showAlert) {
            Alert(title: Text("Cadastro"), message: Text(viewmodelcadastro.alertMessage), dismissButton: .default(Text("OK")))
        }
    }
}

#Preview {
    CadastroPaiView()
}

