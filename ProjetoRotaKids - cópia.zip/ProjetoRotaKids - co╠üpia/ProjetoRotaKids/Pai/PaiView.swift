//
//  PaiView.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 13/05/25.
//

import SwiftUI

struct PaiView: View {
    
@StateObject var viewmodelpai = ViewModelPai()
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.azulclaro
                    .ignoresSafeArea()
                ForEach(viewmodelpai.pais, id: \.self){ index in
                    VStack{
                        Spacer(minLength: 130)
                        HStack {
                            AsyncImage(url: URL(string: index.foto)) {image in
                                image.image?.resizable()
                                    .frame(width: 100, height: 100)
                                    .cornerRadius(50)
                                    .padding()
                            }
                            Text(index.nome)
                                .font(.title)
                            Spacer()
                            Image(systemName: "line.3.horizontal")
                                .font(.title)
                                .padding()
                        }
                        Text("Crianças cadastradas")
                            .padding()
                            .font(.title)
                        Spacer()
                        ForEach(index.criancas, id: \.self){ kids in
                            NavigationLink(destination: MenuKidsView()){
                                HStack{
                                    AsyncImage(url: URL(string: kids.foto)) {image in
                                        image.image?.resizable()
                                            .frame(width: 100, height: 100)
                                            .cornerRadius(50)
                                            .padding()
                                    }
                                    Text(kids.apelido)
                                        .font(.title)
                                        .foregroundColor(.black)
                                }
                                Spacer()
                            }
                            Spacer(minLength: 350)
                        }
                    }
                }
            }
            .onAppear(){
                viewmodelpai.fetch()
            }
        }
    }
}

#Preview {
    PaiView()
}
