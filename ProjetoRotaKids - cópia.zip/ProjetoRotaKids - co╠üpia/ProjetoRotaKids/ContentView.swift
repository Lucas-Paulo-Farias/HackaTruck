//
//  ContentView.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 13/05/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack{
            ZStack{
                Color.azulclaro
                    .ignoresSafeArea()
                VStack{
                    Image("rotakidspng")
                        .resizable()
                        .scaledToFit()
                    NavigationLink(destination: MenuMotoristaView()){
                        ZStack{
                            Rectangle()
                                .foregroundColor(.azul)
                                .frame(width: 250, height: 100)
                            Text("MOTORISTA")
                                .font(.title)
                                .bold()
                                .foregroundColor(.laranja)
                        }
                    }
                        NavigationLink (destination: MenuPaiView()) {
                            ZStack{
                            Rectangle()
                                .foregroundColor(.azul)
                                .frame(width: 250, height: 100)
                            Text("PAI")
                                .font(.title)
                                .bold()
                                .foregroundColor(.laranja)
                        }
                    }
                    Spacer()
                }
            }
        }
    }
}
#Preview {
    ContentView()
}
