//
//  ListaCriancaView.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 16/05/25.
//

import SwiftUI

struct ListaCriancasView: View {
    @StateObject var vm = ViewModelMotorista()
    @StateObject var vmkid = ViewModelCrianca()
    
    var body: some View {
        NavigationStack{
            ZStack{
                Color.azulclaro
                    .ignoresSafeArea(.all)
                VStack {
                    Image("rotakidspng")
                        .resizable()
                        .frame(width: 180, height: 180)
                    ScrollView(.vertical){
                        ForEach(vmkid.criancas, id: \.self){
                            crianca in
                                HStack {
                                    NavigationLink(destination: CriancaView(kid: crianca)){
                                        AsyncImage(url: URL(string: "\(crianca.foto)"), content: {
                                            image in
                                            
                                            image.resizable()
                                        }, placeholder: {
                                            ProgressView()
                                        })
                                        .frame(width: 80, height: 80)
                                        .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/, style: /*@START_MENU_TOKEN@*/FillStyle()/*@END_MENU_TOKEN@*/)
                                        VStack(alignment: .leading){
                                            Text("\(crianca.apelido)")
                                                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                                                .foregroundStyle(.black)
                                            Text("\(crianca.idMotora)")
                                                .font(.subheadline)
                                                .foregroundStyle(.black)
                                        }
                                        Spacer()
        
                                        HStack{
                                            Button(action: { mandapos(idMotora: crianca.idMotora, idPai: crianca.idPai, nome: crianca.apelido, statusCrianca: true) } , label: {
                                                Circle()
                                                    .fill(.green)
                                                    .frame(width: 30, height: 30)
                                            })
                                            .padding(14.0)
                                            Button(action: { mandapos(idMotora: crianca.idMotora, idPai: crianca.idPai, nome: crianca.apelido, statusCrianca: false) } , label: {
                                                Circle()
                                                    .fill(.red)
                                                    .frame(width: 30, height: 30)
                                            })
                                        }
                                        .padding()
                                    }
                            }
                        }
                        
                    }
                }
            }
        }
        .onAppear(){
            vmkid.fetch()
        }
    }
    
    func mandapos(idMotora: String, idPai: String, nome: String, statusCrianca: Bool){
        vm.kidStatus(idMoto: idMotora, idPai: idPai, nome: nome, status: statusCrianca)
    }
}

#Preview {
    ListaCriancasView()
}
