//
//  MotoristaView.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 15/05/25.
//

import SwiftUI

struct MotoristaView: View {

    @StateObject var viewmodelmotorista = ViewModelMotorista()

    var body: some View {
        NavigationStack {
            ZStack{
                Color(.azulclaro)
                    .ignoresSafeArea()
                ForEach(viewmodelmotorista.motora, id: \.self) { motorista in
                    VStack {
                        HStack {
                            AsyncImage(url: URL(string: motorista.foto)) { image in
                                image
                                    .image?.resizable()
                                    .frame(width: 80, height: 80)
                                    .clipShape(Circle(), style: FillStyle())
                            }
                            VStack{
                                Text("\(motorista.nome)")
                                Text("CNH: \(motorista.cnh)")
                                Text("Telefone: \(motorista.telefone)")
                            }
                        }
                        Text("Informações da van:")
                            .padding(.top)
                            .font(.title)
                            .bold()
                        let veiculo = motorista.veiculos

                        AsyncImage(url: URL(string: veiculo.foto)) { image in
                            image
                                .image?.resizable()
                                .frame(width: 250, height: 250)
                        }
                        
                        HStack{
                            Text("Modelo: \(veiculo.modelo)")
                                .font(.callout)
                                .bold()
                        }
                        HStack{
                            Text("Placa: \(veiculo.placa)")
                                .font(.callout)
                                .bold()
                        }
                        HStack{
                            Text("Cor: \(veiculo.cor)")
                                .font(.callout)
                                .bold()
                        }
                        Spacer()
                    }
                }
            }            .onAppear(){
                viewmodelmotorista.fetch()
            }
        }
    }
}

#Preview {
    MotoristaView()
}
