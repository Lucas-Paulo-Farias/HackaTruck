//
//  ViewModelPai.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 13/05/25.
//

import Foundation
import MapKit

struct MotoristaLocation: Equatable {
    let latitude: Double
    let longitude: Double
    var coordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
}

class ViewModelPai: ObservableObject {
    
    @Published var pais: [Pai] = []
    @Published var notificacoes: [Notificacao] = []
    @Published var motoristaLocation: MotoristaLocation?
    @Published var locais: [Localizacao] = []
    
    @Published var isLoadingLocalizacao: Bool = false
    @Published var errorMessageLocalizacao: String?
    
    init(){
        fetch()
    }
    
    func fetch() {
        guard let url = URL(string: "http://127.0.0.1:1880/v1/rotakidspai") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            
            guard let data = data, error == nil else {
                return
            }
            
            do {
                let parsed = try JSONDecoder().decode([Pai].self, from: data)
                DispatchQueue.main.async {
                    self?.pais = parsed
                }
            } catch {
                print(error)
            }
        }
        task.resume()
    }
    

    func obterLocalizacaoDoMotorista() {
        isLoadingLocalizacao = true
        errorMessageLocalizacao = nil
        
        let urlString = "http://192.168.128.7:1880/locations"
        guard let url = URL(string: urlString) else {
            errorMessageLocalizacao = "URL inválida."
            isLoadingLocalizacao = false
            return
        }
        
        URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
            DispatchQueue.main.async {
                self?.isLoadingLocalizacao = false
                if let error = error {
                    self?.errorMessageLocalizacao = "Erro ao obter localização: \(error.localizedDescription)"
                    return
                }
                
                guard let data = data else {
                    self?.errorMessageLocalizacao = "Dados de localização não encontrados."
                    return
                }
                
                do {
                    let parsed = try JSONDecoder().decode([Localizacao].self, from: data)
                    self?.locais = parsed
                    
                } catch {
                    self?.errorMessageLocalizacao = "Erro ao decodificar JSON da localização: \(error.localizedDescription)"
                }
            }
        }.resume()
    }
}
