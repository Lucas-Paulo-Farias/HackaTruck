//
//  MapaView.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 14/05/25.
//

import SwiftUI
import MapKit

struct MapaPaiView: View {
    @StateObject var viewModelPai = ViewModelPai()
    //@StateObject var vmMotorista = ViewModelMotorista()
    
    @State private var position: MapCameraPosition = .region(MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: -15.8638, longitude: -48.0327),
        span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
    ))
    
//    init(motoristaId: String) {
//        self.motoristaId = motoristaId
//    }
    
    @State  var latAux: Double = 0
    @State  var longAux: Double = 0
    var body: some View {
        VStack {
            Text("Localização da Van do Motorista")
                .font(.title2)
                .bold()
                .padding()
            //
            //            if viewModelPai.isLoadingLocalizacao {
            //                ProgressView("Buscando localização...")
            //            } else if let errorMessage = viewModelPai.errorMessageLocalizacao {
            //                Text("Erro: \(errorMessage)")
            //                    .foregroundColor(.red)
            //            } else if let location = viewModelPai.motoristaLocation {
            
            Map(position: $position) {
                ForEach(viewModelPai.locais, id: \.self){
                    loc in
                    
                    Annotation("Van", coordinate: CLLocationCoordinate2D(latitude: loc.latitude, longitude: loc.longitude)) {
                        VStack {
                            Image(systemName: "car.fill")
                                .font(.title)
                                .foregroundColor(.blue)
                        }
                        .padding(5)
                        .background(Color.white.opacity(0.8))
                        .cornerRadius(8)
                        .shadow(radius: 3)
                        
                        .onTapGesture {
                            
                            latAux = loc.latitude
                            longAux = loc.longitude
                        }
                        //                            .onChange(of: <#T##V#>, <#T##(V, V) -> Void#>)() {
                        //                                latAux = loc.latitude
                        //                                longAux = loc.longitude
                        //                            }
                    }
                }
                
                
            }
            .onAppear {
               
                viewModelPai.obterLocalizacaoDoMotorista()

                Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { _ in
                    position = MapCameraPosition.region(MKCoordinateRegion(
                        center: CLLocationCoordinate2D(latitude: latAux, longitude: longAux),
                        span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)))
                }
                
                print(latAux)
                print(longAux)
                
            }
        }
//                .onChange(of: viewModelPai.motoristaLocation) { oldLocation, newLocation in
//                    
//                    if let newLoc = newLocation {
//                        position = .region(MKCoordinateRegion(center: newLoc.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)))
//                    }
//                }
                                                 
                                                 
//            } else {
//                Text("Localização do motorista não disponível.")
//            }
        }

    }


struct IdentifiableLocation: Identifiable {
    let id: String
    let latitude: Double
    let longitude: Double
    var coordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
}

#Preview {
    MapaPaiView()
}
