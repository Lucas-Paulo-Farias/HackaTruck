//
//  ConfigPaiView.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 14/05/25.
//

import SwiftUI

struct ConfigPaiView: View {
    @StateObject var vmpai = ViewModelPai()
    
    var body: some View {
        ZStack{
            Color(.azulclaro)
                .ignoresSafeArea()
            VStack{
                ForEach(vmpai.pais, id: \.self){ index in
                    AsyncImage(url: URL(string: index.foto)) { image in
                        image
                            .image?.resizable()
                            .frame(width: 250, height: 250)
                    }
                    
                    HStack{
                        Text("Nome: \(index.nome)")
                            .font(.callout)
                            .bold()
                    }
                    HStack{
                        Text("Telefone: \(index.telefone)")
                            .font(.callout)
                            .bold()
                    }
                    Spacer()
                }
            }
        }
        .onAppear(){
            vmpai.fetch()
        }
    }
}

#Preview {
    ConfigPaiView()
}
