//
//  ViewModelMotorista.swift
//  testerotakids
//
//  Created by Igor Teles Lima  on 15/05/25.
//

import Foundation

class ViewModelMotorista: ObservableObject {
    
    @Published var motoristas: [Motorista] = []
    
    func fetch(){
        guard let url = URL(string: "http://127.0.0.1:1880/v1/rotakidsmotorista") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url){ [weak self] data, _, error in
            
            guard let data = data, error == nil else {
                return
            }
            
            do {
                let parsed = try JSONDecoder().decode([Motorista].self, from: data)
                
                DispatchQueue.main.async {
                    self?.motoristas = parsed
                }
            } catch {
                print(error)
            }
        }
        
        task.resume()
    }
}
