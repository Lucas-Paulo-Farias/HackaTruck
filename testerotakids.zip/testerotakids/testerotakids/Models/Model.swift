//
//  Model.swift
//  testerotakids
//
//  Created by Igor Teles Lima  on 15/05/25.
//

import Foundation

struct CadastroPaiFilho: Codable {
    let nomeResponsavel: String
    let telefoneResponsavel: String
    let enderecoResponsavel: String
    let apelidoCrianca: String
    let observacoesCrianca: String?
}

struct Localizacao: Codable, Hashable {
    let latitude: Double
    let longitude: Double
    let timestamp: Date
}

struct Motorista: Codable, Hashable, Identifiable {
    let id: Int
    let nome: String
    let cnh: String
    let foto: String
    let telefone: String
    let vanId: Int?
    var localizacaoAtual: Localizacao?
}

struct Veiculo: Codable, Hashable, Identifiable {
    let id: Int
    let placa: String
    let modelo: String
    let foto: String
    let cor: String
}

struct Pai: Codable, Hashable, Identifiable {
    let id: Int
    let nome: String?
    let foto: String?
    let telefone: String?
    let endereco: String
    let latitude: Double?
    let longitude: Double?
    var childrenIds: [Int] // Array de IDs das crianças cadastradas 
}

struct Crianca: Codable, Hashable, Identifiable {
    let id: Int
    let apelido: String
    let foto: String?
    let colegio: String
    let horario: String
    let observacoes: String?
    let latitudeEscola: Double?
    let longitudeEscola: Double?
}

struct AtribuicaoVanCrianca: Codable, Hashable {
    let vanId: Int
    let criancaId: Int
}
