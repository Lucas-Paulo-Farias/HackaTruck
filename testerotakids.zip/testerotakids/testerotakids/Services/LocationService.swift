//
//  LocationService.swift
//  testerotakids
//
//  Created by Igor Teles Lima  on 15/05/25.
//

import Foundation
import CoreLocation

class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    var locationManager = CLLocationManager()
    @Published var authorizationStatus: CLAuthorizationStatus?
    @Published var lastLocation: CLLocation?

    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        locationManager.distanceFilter = 10
    }

    func startUpdatingLocation() {
        if locationManager.authorizationStatus == .notDetermined {
            locationManager.requestWhenInUseAuthorization()
        } else if locationManager.authorizationStatus == .authorizedWhenInUse {
            locationManager.startUpdatingLocation()
        } else {
            print("Permissão de localização não concedida.")
        }
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        authorizationStatus = manager.authorizationStatus
        switch manager.authorizationStatus {
        case .authorizedWhenInUse:
            lastLocation = nil
            startUpdatingLocation()
            break

        case .restricted:
            print("Serviços de localização restritos.")
            break

        case .denied:
            print("Permissão de localização negada pelo usuário.")
            break

        case .notDetermined:
            break

        default:
            break
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last {
            lastLocation = location
            print("Nova localização: \(location.coordinate.latitude), \(location.coordinate.longitude)")
            sendLocationToBackend(location: location)
        }
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Erro ao obter a localização: \(error.localizedDescription)")

    }

    func stopLocation() {
        locationManager.stopUpdatingLocation()
    }

    func sendLocationToBackend(location: CLLocation) {
        guard let url = URL(string: "http://127.0.0.1:1880/location") else {
            print("URL do backend inválida.")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let jsonData: [String: Any] = [
            "latitude": location.coordinate.latitude,
            "longitude": location.coordinate.longitude,
            "altitude": location.altitude,
            "timestamp": location.timestamp.timeIntervalSince1970
        ]

        do {
            let httpBody = try JSONSerialization.data(withJSONObject: jsonData)
            request.httpBody = httpBody

            let session = URLSession.shared
            let task = session.dataTask(with: request) { (data, response, error) in
                if let error = error {
                    print("Erro ao enviar a localização: \(error.localizedDescription)")
                    return
                }

                if let httpResponse = response as? HTTPURLResponse {
                    print("Resposta do servidor: \(httpResponse.statusCode)")
                    if let data = data {
                        if let responseString = String(data: data, encoding: .utf8) {
                            print("Dados da resposta: \(responseString)")
                        }
                    }
                }
            }
            task.resume()
        } catch {
            print("Erro ao serializar JSON: \(error.localizedDescription)")
        }
    }
}

