//
//  testerotakidsApp.swift
//  testerotakids
//
//  Created by Igor Teles Lima  on 15/05/25.
//

import SwiftUI

@main
struct testerotakidsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
