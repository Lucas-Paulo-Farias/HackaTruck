//
//  CadastroView.swift
//  testerotakids
//
//  Created by Igor Teles Lima  on 15/05/25.
//

import SwiftUI

struct CadastroView: View {
    @StateObject var viewModel = ViewModelCadastro()
    
    var body: some View {
        ZStack {
            Color.amarelo
                .ignoresSafeArea()
            
            ScrollView {
                VStack(alignment: .leading) {
                    HStack {
                        Image("RotaKids")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80, height: 80)
                        Spacer()
                    }
                    .padding(.horizontal)
                    .background()
                    
                    VStack(alignment: .leading) {
                        Text("Nome do Responsável:")
                            .foregroundColor(.letra)
                            .bold()
                            .font(.system(size: 22))
                        TextField("  Nome:", text: $viewModel.nome)
                            .background(RoundedRectangle(cornerRadius: 50).fill(.white).frame(height: 30))
                        
                        Text("Telefone do Responsável:")
                            .bold()
                            .foregroundColor(.letra)
                            .font(.system(size: 22))
                        TextField("  Telefone:", text: $viewModel.telefone)
                            .background(RoundedRectangle(cornerRadius: 50).fill(.white).frame(height: 30))
                        
                        Text("Endereço:")
                            .bold()
                            .foregroundColor(.letra)
                            .font(.system(size: 22))
                        TextField("  Endereço:", text: $viewModel.endereco)
                            .background(RoundedRectangle(cornerRadius: 50).fill(.white).frame(height: 30))
                        
                        Text("Criança:")
                            .bold()
                            .foregroundColor(.letra)
                            .font(.system(size: 22))
                        TextField("  Apelido:", text: $viewModel.apelido)
                            .background(RoundedRectangle(cornerRadius: 50).fill(.white).frame(height: 30))
                        
                        Text("Observações:")
                            .bold()
                            .foregroundColor(.letra)
                            .font(.system(size: 22))
                        TextField("  Observações:", text: $viewModel.observacoes, axis: .vertical)
                            .textFieldStyle(.roundedBorder)
                        
                        Spacer(minLength: 40)
                    }
                    .padding(.horizontal)
                    
                    HStack {
                        Spacer()
                        Button("Cadastrar") {
                            viewModel.enviarDadosCadastro()
                        }
                        .foregroundColor(.white)
                        .bold()
                        .padding(.horizontal, 40)
                        .padding(.vertical, 15)
                        .background(RoundedRectangle(cornerRadius: 50).fill(.botao))
                        .padding(.trailing, 20)
                        .disabled(viewModel.isLoading) // Desabilita o botão durante o carregamento
                        
                        if viewModel.isLoading {
                            ProgressView()
                        }
                        Spacer()
                    }
                    .padding(.horizontal)
                    
                    Spacer()
                }
            }
        }
        .alert(isPresented: $viewModel.showAlert) {
            Alert(title: Text("Cadastro"), message: Text(viewModel.alertMessage), dismissButton: .default(Text("OK")))
        }
    }
}

#Preview {
    CadastroView()
}
