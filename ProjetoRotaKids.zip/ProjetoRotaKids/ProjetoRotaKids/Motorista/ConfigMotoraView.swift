//
//  ConfigMotoraView.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 15/05/25.
//

import SwiftUI

struct ConfigMotoraView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    ConfigMotoraView()
}
