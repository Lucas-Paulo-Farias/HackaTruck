//
//  ProjetoRotaKidsApp.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 13/05/25.
//

import SwiftUI

@main
struct ProjetoRotaKidsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
